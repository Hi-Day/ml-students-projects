package com.mycompany.lightenup

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
